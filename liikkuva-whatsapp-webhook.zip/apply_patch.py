#!/usr/bin/env python3
"""Safely apply WhatsApp webhook to a clone of vitaliimed/liikkuvakorjaamo.
Usage: python3 apply_patch.py /path/to/liikkuva
"""
from pathlib import Path
import shutil
import sys

root = Path(sys.argv[1] if len(sys.argv)>1 else '.').resolve()
source = root/'source' if (root/'source'/'router.go').exists() else root
router = source/'router.go'
brand = source/'liikkuva_brand.go'
if not router.exists() or not brand.exists() or not (source/'services_firestore.go').exists():
    raise SystemExit('Not a recognizable Liikkuva Go source tree: '+str(source))

files = ['handlers_whatsapp.go', 'services_whatsapp.go', 'handlers_whatsapp_test.go']
for f in files:
    target = source/f
    if target.exists():
        raise SystemExit(f'Existing file {target}: aborting to avoid overwriting changes')

text = router.read_text()
anchor = '\tmux.HandleFunc("/lead", leads.Submit)'
if anchor not in text: raise SystemExit('Cannot locate /lead route; router has changed')
text = text.replace(anchor, anchor + '\n\tmux.HandleFunc("/webhooks/whatsapp", WhatsAppWebhookHandler(func(ctx context.Context, event metaWhatsAppEnvelope) error {\n\t\treturn saveMetaWhatsAppEvents(ctx, cfg, event)\n\t}))', 1)
if '"context"' not in text:
    text = text.replace('import "net/http"', 'import (\n\t"context"\n\t"net/http"\n)')

bt = brand.read_text()
# Bootstrap mode protects lead submission, but signed WhatsApp webhook must stay reachable.
needle = '&& !strings.HasPrefix(r.URL.Path, "/admin")'
if needle in bt:
    bt = bt.replace(needle, needle + ' && r.URL.Path != "/webhooks/whatsapp"', 1)
elif 'if os.Getenv("LIIKKUVA_BOOTSTRAP") == "1" && r.Method != "GET" {' in bt:
    bt = bt.replace('if os.Getenv("LIIKKUVA_BOOTSTRAP") == "1" && r.Method != "GET" {', 'if os.Getenv("LIIKKUVA_BOOTSTRAP") == "1" && r.Method != "GET" && r.URL.Path != "/webhooks/whatsapp" {', 1)
elif 'LIIKKUVA_BOOTSTRAP' in bt:
    raise SystemExit('Unexpected bootstrap middleware version: please inspect it manually')

shutil.copy2(router, router.with_suffix('.go.whatsapp-backup'))
shutil.copy2(brand, brand.with_suffix('.go.whatsapp-backup'))
for f in files: shutil.copy2(Path(__file__).parent/'source'/f, source/f)
router.write_text(text)
brand.write_text(bt)
print(f'Patch applied to {source}. Backups *.go.whatsapp-backup created.')
print('Run: cd', source, '&& gofmt -w handlers_whatsapp.go services_whatsapp.go handlers_whatsapp_test.go router.go liikkuva_brand.go && go test ./...')
