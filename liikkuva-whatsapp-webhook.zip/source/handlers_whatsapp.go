package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"crypto/subtle"
	"encoding/hex"
	"encoding/json"
	"errors"
	"io"
	"log"
	"net/http"
	"os"
	"strings"
)

// WhatsApp is authenticated by the Meta App Secret, not by the API Access Token.
// The verify token is a separate, randomly generated value used for GET challenge setup.
const whatsappMaxPayloadBytes int64 = 1 << 20

type metaWhatsAppEnvelope struct {
	Object string `json:"object"`
	Entry  []struct {
		ID      string `json:"id"`
		Changes []struct {
			Field string            `json:"field"`
			Value metaWhatsAppValue `json:"value"`
		} `json:"changes"`
	} `json:"entry"`
}

type metaWhatsAppValue struct {
	Metadata struct {
		DisplayPhoneNumber string `json:"display_phone_number"`
		PhoneNumberID      string `json:"phone_number_id"`
	} `json:"metadata"`
	Contacts []struct {
		Profile struct {
			Name string `json:"name"`
		} `json:"profile"`
		WAID string `json:"wa_id"`
	} `json:"contacts"`
	Messages []struct {
		From      string `json:"from"`
		ID        string `json:"id"`
		Timestamp string `json:"timestamp"`
		Type      string `json:"type"`
		Text      struct {
			Body string `json:"body"`
		} `json:"text"`
		Image struct {
			ID       string `json:"id"`
			MIMEType string `json:"mime_type"`
			Caption  string `json:"caption"`
		} `json:"image"`
		Document struct {
			ID       string `json:"id"`
			Filename string `json:"filename"`
			MIMEType string `json:"mime_type"`
			Caption  string `json:"caption"`
		} `json:"document"`
		Audio struct {
			ID       string `json:"id"`
			MIMEType string `json:"mime_type"`
		} `json:"audio"`
		Video struct {
			ID       string `json:"id"`
			MIMEType string `json:"mime_type"`
			Caption  string `json:"caption"`
		} `json:"video"`
		Button struct {
			Text    string `json:"text"`
			Payload string `json:"payload"`
		} `json:"button"`
		Interactive json.RawMessage `json:"interactive"`
	} `json:"messages"`
	Statuses []struct {
		ID          string          `json:"id"`
		Status      string          `json:"status"`
		Timestamp   string          `json:"timestamp"`
		RecipientID string          `json:"recipient_id"`
		Errors      json.RawMessage `json:"errors"`
	} `json:"statuses"`
}

// WhatsAppWebhookHandler persists the signed delivery before responding 200.
// On storage failure it returns 503 so Meta can retry. Firestore writes are idempotent.
func WhatsAppWebhookHandler(store func(context.Context, metaWhatsAppEnvelope) error) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-store")
		w.Header().Set("X-Robots-Tag", "noindex, nofollow")
		switch r.Method {
		case http.MethodGet:
			token := os.Getenv("WHATSAPP_VERIFY_TOKEN")
			if token == "" {
				http.Error(w, "Webhook not configured", http.StatusServiceUnavailable)
				return
			}
			q := r.URL.Query()
			supplied := q.Get("hub.verify_token")
			if q.Get("hub.mode") != "subscribe" || supplied == "" || subtle.ConstantTimeCompare([]byte(token), []byte(supplied)) != 1 {
				http.Error(w, "Forbidden", http.StatusForbidden)
				return
			}
			challenge := q.Get("hub.challenge")
			if challenge == "" || len(challenge) > 512 {
				http.Error(w, "Invalid challenge", http.StatusBadRequest)
				return
			}
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = io.WriteString(w, challenge)
		case http.MethodPost:
			secret := os.Getenv("WHATSAPP_APP_SECRET")
			if secret == "" {
				http.Error(w, "Webhook not configured", http.StatusServiceUnavailable)
				return
			}
			// Invalid signatures are rejected before parsing or writing any data.
			r.Body = http.MaxBytesReader(w, r.Body, whatsappMaxPayloadBytes)
			body, err := io.ReadAll(r.Body)
			if err != nil {
				var maxErr *http.MaxBytesError
				if errors.As(err, &maxErr) {
					http.Error(w, "Payload too large", http.StatusRequestEntityTooLarge)
				} else {
					http.Error(w, "Invalid request body", http.StatusBadRequest)
				}
				return
			}
			signature := r.Header.Get("X-Hub-Signature-256")
			if !strings.HasPrefix(signature, "sha256=") {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}
			digest, err := hex.DecodeString(strings.TrimPrefix(signature, "sha256="))
			if err != nil || len(digest) != sha256.Size {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}
			mac := hmac.New(sha256.New, []byte(secret))
			_, _ = mac.Write(body)
			if !hmac.Equal(digest, mac.Sum(nil)) {
				http.Error(w, "Unauthorized", http.StatusUnauthorized)
				return
			}
			var event metaWhatsAppEnvelope
			if err := json.Unmarshal(body, &event); err != nil || event.Object != "whatsapp_business_account" {
				http.Error(w, "Invalid WhatsApp event", http.StatusBadRequest)
				return
			}
			if store == nil {
				http.Error(w, "Storage not configured", http.StatusServiceUnavailable)
				return
			}
			if err := store(r.Context(), event); err != nil {
				// Only the error is logged, never the raw WhatsApp payload or secrets.
				log.Printf("WhatsApp Firestore storage failed: %v", err)
				http.Error(w, "Temporary storage error", http.StatusServiceUnavailable)
				return
			}
			w.Header().Set("Content-Type", "text/plain; charset=utf-8")
			_, _ = io.WriteString(w, "EVENT_RECEIVED")
		default:
			w.Header().Set("Allow", "GET, POST")
			http.Error(w, "Method not allowed", http.StatusMethodNotAllowed)
		}
	}
}
