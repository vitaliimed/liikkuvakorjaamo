package main

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"net/http"
	"net/http/httptest"
	"net/url"
	"strings"
	"testing"
)

func TestWhatsAppWebhookVerify(t *testing.T) {
	t.Setenv("WHATSAPP_VERIFY_TOKEN", "random-verify-token")
	h := WhatsAppWebhookHandler(func(context.Context, metaWhatsAppEnvelope) error { return nil })
	q := url.Values{"hub.mode": {"subscribe"}, "hub.verify_token": {"random-verify-token"}, "hub.challenge": {"123456"}}
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, httptest.NewRequest(http.MethodGet, "/webhooks/whatsapp?"+q.Encode(), nil))
	if rr.Code != 200 || rr.Body.String() != "123456" {
		t.Fatalf("verify: %d %q", rr.Code, rr.Body.String())
	}
	q.Set("hub.verify_token", "bad")
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, httptest.NewRequest(http.MethodGet, "/webhooks/whatsapp?"+q.Encode(), nil))
	if rr.Code != 403 {
		t.Fatalf("bad token: %d", rr.Code)
	}
}

func signedMetaReq(secret, payload string) *http.Request {
	mac := hmac.New(sha256.New, []byte(secret))
	mac.Write([]byte(payload))
	r := httptest.NewRequest(http.MethodPost, "/webhooks/whatsapp", strings.NewReader(payload))
	r.Header.Set("X-Hub-Signature-256", "sha256="+hex.EncodeToString(mac.Sum(nil)))
	return r
}

func TestWhatsAppWebhookSignatureAndDelivery(t *testing.T) {
	t.Setenv("WHATSAPP_APP_SECRET", "test-meta-secret")
	count := 0
	h := WhatsAppWebhookHandler(func(_ context.Context, e metaWhatsAppEnvelope) error {
		count++
		if e.Object != "whatsapp_business_account" {
			t.Fatal("wrong object")
		}
		return nil
	})
	payload := `{"object":"whatsapp_business_account","entry":[{"id":"waba","changes":[{"field":"messages","value":{"messages":[{"from":"358401234567","id":"wamid.1","timestamp":"1700000000","type":"text","text":{"body":"Hei"}}]}}]}]}`
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, signedMetaReq("test-meta-secret", payload))
	if rr.Code != 200 || count != 1 || rr.Body.String() != "EVENT_RECEIVED" {
		t.Fatalf("signed request: %d count=%d body=%s", rr.Code, count, rr.Body.String())
	}
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, signedMetaReq("wrong-secret", payload))
	if rr.Code != 401 || count != 1 {
		t.Fatalf("wrong signature: %d count=%d", rr.Code, count)
	}
	rr = httptest.NewRecorder()
	h.ServeHTTP(rr, signedMetaReq("test-meta-secret", `{"object":"unexpected"}`))
	if rr.Code != 400 {
		t.Fatalf("wrong object: %d", rr.Code)
	}
}

func TestWhatsAppWebhookLimit(t *testing.T) {
	t.Setenv("WHATSAPP_APP_SECRET", "test-meta-secret")
	h := WhatsAppWebhookHandler(func(context.Context, metaWhatsAppEnvelope) error { t.Fatal("should not persist"); return nil })
	rr := httptest.NewRecorder()
	h.ServeHTTP(rr, signedMetaReq("test-meta-secret", strings.Repeat("a", int(whatsappMaxPayloadBytes)+1)))
	if rr.Code != 413 {
		t.Fatalf("oversized: %d", rr.Code)
	}
}
