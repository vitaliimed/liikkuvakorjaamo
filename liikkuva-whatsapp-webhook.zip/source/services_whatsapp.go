package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"fmt"
	"regexp"
	"strconv"
	"strings"
	"time"

	"google.golang.org/grpc/codes"
	"google.golang.org/grpc/status"
)

var whatsappPlateCandidate = regexp.MustCompile(`(?i)\b[A-ZÅÄÖ]{3}-?[0-9]{3}\b`)

func whatsappDocumentID(key string) string {
	sum := sha256.Sum256([]byte(key))
	return hex.EncodeToString(sum[:])
}

func whatsappEventTime(raw string) time.Time {
	sec, err := strconv.ParseInt(raw, 10, 64)
	if err != nil || sec < 1 {
		return time.Now().UTC()
	}
	return time.Unix(sec, 0).UTC()
}

// Messages are stored in the existing named Firestore database: liikkuvakorjaamo.
// Each Meta message ID is a deterministic Firestore document key; retries are safe.
func saveMetaWhatsAppEvents(ctx context.Context, cfg Config, event metaWhatsAppEnvelope) error {
	if strings.TrimSpace(cfg.FirestoreProjectID) == "" {
		return errors.New("Firestore is not configured")
	}
	client, err := newFirestoreClient(ctx, cfg)
	if err != nil {
		return fmt.Errorf("open WhatsApp Firestore: %w", err)
	}
	defer client.Close()

	for _, entry := range event.Entry {
		for _, change := range entry.Changes {
			if change.Field != "messages" {
				continue
			}
			value := change.Value
			names := map[string]string{}
			for _, contact := range value.Contacts {
				names[contact.WAID] = contact.Profile.Name
			}

			for _, m := range value.Messages {
				if m.ID == "" {
					continue
				}
				text := m.Text.Body
				if text == "" {
					switch m.Type {
					case "image":
						text = m.Image.Caption
					case "video":
						text = m.Video.Caption
					case "document":
						text = m.Document.Caption
					case "button":
						text = m.Button.Text
					}
				}
				mediaID, mimeType := "", ""
				switch m.Type {
				case "image":
					mediaID, mimeType = m.Image.ID, m.Image.MIMEType
				case "document":
					mediaID, mimeType = m.Document.ID, m.Document.MIMEType
				case "audio":
					mediaID, mimeType = m.Audio.ID, m.Audio.MIMEType
				case "video":
					mediaID, mimeType = m.Video.ID, m.Video.MIMEType
				}
				plate := strings.ToUpper(whatsappPlateCandidate.FindString(text))
				if plate != "" && !strings.Contains(plate, "-") {
					plate = plate[:3] + "-" + plate[3:]
				}
				doc := map[string]any{
					"source": "whatsapp", "message_id": m.ID, "wa_id": m.From,
					"contact_name": names[m.From], "phone_number_id": value.Metadata.PhoneNumberID,
					"message_type": m.Type, "text_original": text, "car_plate_candidate": plate,
					"media_id": mediaID, "media_mime_type": mimeType,
					"media_download_status": "not_downloaded", "timestamp": whatsappEventTime(m.Timestamp),
					"received_at": time.Now().UTC(), "crm_status": "new",
				}
				_, err := client.Collection("whatsapp_messages").Doc(whatsappDocumentID(m.ID)).Create(ctx, doc)
				if err != nil && status.Code(err) != codes.AlreadyExists {
					return fmt.Errorf("store inbound WhatsApp message: %w", err)
				}
			}
			for _, s := range value.Statuses {
				if s.ID == "" || s.Status == "" {
					continue
				}
				key := s.ID + ":" + s.Status + ":" + s.Timestamp
				doc := map[string]any{
					"message_id": s.ID, "status": s.Status, "recipient_id": s.RecipientID,
					"phone_number_id": value.Metadata.PhoneNumberID,
					"timestamp":       whatsappEventTime(s.Timestamp), "received_at": time.Now().UTC(),
				}
				_, err := client.Collection("whatsapp_status_events").Doc(whatsappDocumentID(key)).Create(ctx, doc)
				if err != nil && status.Code(err) != codes.AlreadyExists {
					return fmt.Errorf("store WhatsApp status: %w", err)
				}
			}
		}
	}
	return nil
}
