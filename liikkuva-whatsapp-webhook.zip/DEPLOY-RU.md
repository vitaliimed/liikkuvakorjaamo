# Liikkuva CRM Bot — установка WhatsApp Webhook

Патч предназначен для существующего репозитория vitaliimed/liikkuvakorjaamo, Go-сервер в `source/`.
Он **не отправляет** сообщения клиентам и **не переводит** их пока. Первый этап — безопасный приём сообщений и статусов из Meta и сохранение в Firestore.

## 0. Защита ключей

- Ранее на скриншоте был виден **временный Access Token**. Отзовите/перевыпустите его в Meta; новый не публикуйте.
- **Meta App Secret** берите в **App settings → Basic → App secret → Show**. Он нужен для проверки входящих сообщений.
- **Verify Token** — случайная строка, которую создаём сами, не путать с Access Token.
- Все секреты храним в **Google Secret Manager**, не в `.env`, репозитории или истории терминала.

## 1. Установка файлов в Cloud Shell

1. Загрузите архив `liikkuva-whatsapp-webhook.zip` через **Cloud Shell → Upload file**.
2. Выполните:

```bash
cd "$HOME/liikkuva"
git status --short
git switch -c feat/whatsapp-webhook
mkdir -p "$HOME/whatsapp-patch"
unzip -oq "$HOME/liikkuva-whatsapp-webhook.zip" -d "$HOME/whatsapp-patch"
python3 "$HOME/whatsapp-patch/apply_patch.py" "$HOME/liikkuva"
cd "$HOME/liikkuva/source"
gofmt -w handlers_whatsapp.go services_whatsapp.go handlers_whatsapp_test.go router.go liikkuva_brand.go
go test ./...
```

> Если архив загружен под другим именем, замените только имя файла. Перед `git switch` убедитесь, что нет важных незакоммиченных изменений; при их наличии сохраните их отдельно.

## 2. Создание секретов

```bash
PROJECT=liikkuva-korjaamo
REGION=europe-north1
SERVICE=liikkuva-preview

gcloud config set project "$PROJECT"
gcloud services enable secretmanager.googleapis.com --project "$PROJECT"

for NAME in whatsapp-app-secret whatsapp-verify-token; do
  gcloud secrets describe "$NAME" --project "$PROJECT" >/dev/null 2>&1 || \
    gcloud secrets create "$NAME" --project "$PROJECT" --replication-policy=automatic
done

read -r -s -p 'Paste META APP SECRET (not Access Token): ' META_APP_SECRET; echo
printf %s "$META_APP_SECRET" | gcloud secrets versions add whatsapp-app-secret --project "$PROJECT" --data-file=-
unset META_APP_SECRET

VERIFY_TOKEN="$(openssl rand -hex 32)"
printf %s "$VERIFY_TOKEN" | gcloud secrets versions add whatsapp-verify-token --project "$PROJECT" --data-file=-
unset VERIFY_TOKEN
```

Проверьте имя сервиса (в Cloud Run могут быть `liikkuva-preview`, `liikkuva-landing` или другие):

```bash
gcloud run services list --project "$PROJECT" --region "$REGION"
```

Для указанного `SERVICE` получаем service account и предоставляем доступ **только к двум новым секретам**:

```bash
SA="$(gcloud run services describe "$SERVICE" --project "$PROJECT" --region "$REGION" --format='value(spec.template.spec.serviceAccountName)')"
if [ -z "$SA" ]; then
  PROJECT_NUMBER="$(gcloud projects describe "$PROJECT" --format='value(projectNumber)')"
  SA="${PROJECT_NUMBER}-compute@developer.gserviceaccount.com"
fi
printf 'Cloud Run runtime SA: %s\n' "$SA"
for NAME in whatsapp-app-secret whatsapp-verify-token; do
  gcloud secrets add-iam-policy-binding "$NAME" --project "$PROJECT" \
    --member="serviceAccount:$SA" --role=roles/secretmanager.secretAccessor
done
```

Существующему runtime SA также нужен доступ на запись в Firestore (`roles/datastore.user`). Если текущий сайт уже записывает заявки, он может быть предоставлен ранее. Не выдавайте новый доступ вслепую.

## 3. Развёртывание без смены рабочего трафика

ПИННИНГ версий — указываем номера созданных версий, а не latest:

```bash
SECRET_VERSION="$(gcloud secrets versions list whatsapp-app-secret --project "$PROJECT" --filter='state=ENABLED' --sort-by='~createTime' --limit=1 --format='value(name)' | awk -F/ '{print $NF}')"
VERIFY_VERSION="$(gcloud secrets versions list whatsapp-verify-token --project "$PROJECT" --filter='state=ENABLED' --sort-by='~createTime' --limit=1 --format='value(name)' | awk -F/ '{print $NF}')"

cd "$HOME/liikkuva"
gcloud run deploy "$SERVICE" --project "$PROJECT" --region "$REGION" \
  --source ./source --no-traffic --tag whatsapp-preview \
  --update-secrets="WHATSAPP_APP_SECRET=whatsapp-app-secret:${SECRET_VERSION},WHATSAPP_VERIFY_TOKEN=whatsapp-verify-token:${VERIFY_VERSION}"

CALLBACK_BASE="$(gcloud run services describe "$SERVICE" --project "$PROJECT" --region "$REGION" --format=json | jq -r '.status.traffic[] | select(.tag == "whatsapp-preview") | .url')"
[ -n "$CALLBACK_BASE" ] && [ "$CALLBACK_BASE" != null ] || { echo 'Tag URL not found'; exit 1; }
printf 'META CALLBACK URL: %s/webhooks/whatsapp\n' "$CALLBACK_BASE"
curl -sS -o /dev/null -w 'Webhook GET without token HTTP %{http_code}\n' "$CALLBACK_BASE/webhooks/whatsapp"
```

Если возвращается **403**, маршрут доступен (и правильно требует verify-token). **401/403 на уровне Cloud Run IAM** также возможны, если сервис не разрешает внешние запросы; проверьте, что сервис уже имеет публичный доступ к веб-сайту. Не нужно делать публичным весь проект или Firestore.

В **Meta** получите Verify Token для копирования через Cloud Shell (вывод будет секретным, не публикуйте):

```bash
gcloud secrets versions access "$VERIFY_VERSION" --secret=whatsapp-verify-token --project="$PROJECT"
```

## 4. Meta Developers

App → Use cases → Connect on WhatsApp → Customize → **Webhooks / Configuration** (название зависит от текущего интерфейса):

- Callback URL: `https://<URL новой tagged revision>/webhooks/whatsapp` — используйте вывод команды выше, **не** домен сайта, пока новая ревизия не стала основной.
- Verify Token: значение `whatsapp-verify-token` из Secret Manager.
- Нажмите **Verify and Save**.
- Подпишитесь на поле **messages** для WhatsApp Business Account. Одной проверки URL недостаточно.

Отправьте с личного телефона новое WhatsApp сообщение тестовому номеру Meta. При корректной подписке и разрешённых тестовых отправителях сообщение окажется в Firestore (database ID `liikkuvakorjaamo`, collection `whatsapp_messages`). Статусы отправки — в `whatsapp_status_events`.

> Метаданные изображений/документов (media ID) сохраняются, но **сами фото и аудиофайлы пока не загружаются**. CRM и перевод — следующий отдельный этап.

## 5. Проверка Firestore и ошибок

```bash
gcloud firestore databases list --project "$PROJECT"
gcloud logging read \
  'resource.type="cloud_run_revision" AND resource.labels.service_name="'"$SERVICE"'" AND severity>=ERROR' \
  --project "$PROJECT" --limit 20 --format='table(timestamp,severity,textPayload)'
```

Не присылайте полные сырые payload с телефонами или секретами: лучше скриншот Firestore со скрытыми личными данными или коды HTTP.

## 6. Что патч меняет

- `source/handlers_whatsapp.go`: GET challenge, POST HMAC verification, ограничения размера, немедленный HTTP 200 после сохранения.
- `source/services_whatsapp.go`: сохраняет входящие сообщения и статусы в существующую Firestore database `liikkuvakorjaamo`; повторные события игнорируются по ключу документа.
- `source/handlers_whatsapp_test.go`: тесты проверки токена, подписи и размера payload.
- `source/router.go`: добавляет `/webhooks/whatsapp`.
- `source/liikkuva_brand.go`: разрешает **только подписанный Webhook** работать во время bootstrap, не открывая прочие POST-запросы.

Для production: отдельно согласовать статус приложения Meta, реальный WhatsApp номер, шаблоны сообщений, согласие на исходящие сообщения, хранилище персональных данных, retention и автоматическое назначение заявок CRM.
